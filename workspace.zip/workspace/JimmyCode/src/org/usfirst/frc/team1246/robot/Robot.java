

//////////////////////////Made by Jimmy Zhang 2015


package org.usfirst.frc.team1246.robot;

import edu.wpi.first.wpilibj.*;

public class Robot extends IterativeRobot {//http://first.wpi.edu/FRC/roborio/release/eclipse/
    RobotDrive mickeyD;
    Joystick driveStick;
    
    //declare pwm ports
    final int left1 = 0;
    final int left2 = 1;
    final int right1 = 2;
    final int right2 = 3;
    
	// declare the states of driveStick
	final float forward = 1;
	final float neutral = 0;
	final float backward = -1;
	
	// declare the states of liftStick
	final float liftUp = 0.5f;
	final float liftStop = 0;
	final float liftDown = 0.5f;
	
	// buttons for the robot
	final int intake = 2;
	final int extake = 3;
	final int close = 4;
	final int open = 5;
	final int drop = 7;
	final int undrop = 8;
	
	// declare the victors
	Victor left = new Victor(4);
	Victor right = new Victor(5);
	Victor lift = new Victor(6);
	
	// declare the compressor
	Compressor comp = new Compressor();
	
	// declare the solenoids
	DoubleSolenoid sol = new DoubleSolenoid(0, 1);
	
    public void robotInit() {
    	mickeyD = new RobotDrive(left1,left2,right1,right2);
    	mickeyD.setExpiration(0.1);
    	driveStick = new Joystick(0);
    	mickeyD.setInvertedMotor(RobotDrive.MotorType.kFrontLeft, true);
    	mickeyD.setInvertedMotor(RobotDrive.MotorType.kFrontRight, true);
    	mickeyD.setInvertedMotor(RobotDrive.MotorType.kRearLeft, true);
    	mickeyD.setInvertedMotor(RobotDrive.MotorType.kRearRight, true);
    	    	    	
    }
    
    public void autonomousInit() {
    	
    }

    public void autonomousPeriodic() {
    
    }
    
    public void teleopInit() {
    	
    }

    public void teleopPeriodic() {
    	mickeyD.setSafetyEnabled(true);
        while (isOperatorControl() && isEnabled()) {
            mickeyD.arcadeDrive(driveStick); // drive with arcade style (use right stick)
            Timer.delay(0.001); // wait for a motor update time
            if(driveStick.getRawButton(intake)){
            	left.set(forward);
            	right.set(forward);
            }
            else if(driveStick.getRawButton(extake))
            {
            	left.set(backward);
            	right.set(backward);
            }
            else {
            	left.set(neutral);
            	right.set(neutral);
            }
            
            if(driveStick.getRawButton(open)){
            	sol.set(DoubleSolenoid.Value.kForward);
            }
            else if(driveStick.getRawButton(close))
            {
            	sol.set(DoubleSolenoid.Value.kReverse);
            }
            else
            {
            	sol.set(DoubleSolenoid.Value.kOff);
            }
            
            if(driveStick.getRawButton(undrop))
            {
            	lift.set(liftUp);
            }
            else if(driveStick.getRawButton(drop))
            {
            	lift.set(liftDown);
            }
            else 
            {
            	lift.set(liftStop);
            }
        }
    }    
}
