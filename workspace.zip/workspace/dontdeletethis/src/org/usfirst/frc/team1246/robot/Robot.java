
package org.usfirst.frc.team1246.robot;

import edu.wpi.first.wpilibj.*;

public class Robot extends IterativeRobot {
    RobotDrive mickeyD;
    Joystick driveStick;
    
	// declare the states of driveStick
	final int forward = 1;
	final int neutral = 0;
	final int backward = -1;
	
	// buttons for the robot
	final int intake = 1;
	final int up = 3;
	final int down = 2;
	
	// declare the victors
	Victor left = new Victor(5);
	Victor right = new Victor(6);
	
    public void robotInit() {
    	mickeyD = new RobotDrive(forward,forward,forward,forward);
    	mickeyD.setExpiration(0.1);
    	driveStick = new Joystick(1);
    }

    public void autonomousPeriodic() {

    }

    public void teleopPeriodic() {
    	mickeyD.setSafetyEnabled(true);
        while (isOperatorControl() && isEnabled()) {
            mickeyD.arcadeDrive(driveStick); // drive with arcade style (use right stick)
            Timer.delay(0.001);		// wait for a motor update time
        }
        
    }    
}
