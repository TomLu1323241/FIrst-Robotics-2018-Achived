
package org.usfirst.frc.team1246.robot;


import edu.wpi.first.wpilibj.SampleRobot;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.DoubleSolenoid;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.DigitalInput;

/**
 * This is a demo program showing the use of the RobotDrive class.
 * The SampleRobot class is the base of a robot application that will automatically call your
 * Autonomous and OperatorControl methods at the right time as controlled by the switches on
 * the driver station or the field controls.
 *
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SampleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 *
 * WARNING: While it may look like a good choice to use for your code if you're inexperienced,
 * don't. Unless you know what you are doing, complex code will be much more difficult under
 * this system. Use IterativeRobot or Command-Based instead if you're new.
 */
public class Robot extends SampleRobot {
    RobotDrive myRobot;
    Joystick mainJoystick;
    Joystick secondJoystick;
    Compressor compressor;
    DoubleSolenoid intakePiston;
    Victor leftIntakeMotor;
    Victor rightIntakeMotor;
    Victor elevatorMotor1;
    Victor elevatorMotor2;
    //DigitalInput topLimitSwitch;
    //DigitalInput bottomLimitSwitch;
    Talon frontLeft;
    Talon backLeft;
    Talon frontRight;
    Talon backRight;
    
    //buttons mainJoystick
    //final int INCREASE_SPEED = 8;
    //final int DECREASE_SPEED = 9;
    final int ELEVATOR_UP_1 = 3;
    final int ELEVATOR_DOWN_1 = 2;
    final int HOLD_UP_1 = 6;
    final int HOLD_DOWN_1 = 7;
    
    //buttons secondJoystick
    final int OPEN_INTAKE_2 = 6;
    final int CLOSE_INTAKE_2 = 7;
    final int INTAKE_OUT_2 = 3;
    final int INTAKE_IN_2 = 2;
    final int TURN_LEFT_2 = 4;
    final int TURN_RIGHT_2 = 5;
    
    double holdValue = -0.1;
    
    double time = System.currentTimeMillis();
    double speed = 0.5;
    final int INCREASE_SPEED_LIMIT = 8;
    final int DECREASE_SPEED_LIMIT = 9;

    public Robot() {        
        //Joystick
    	mainJoystick = new Joystick(0);
        secondJoystick = new Joystick(1);
        
        //Compressor
        compressor = new Compressor();
        
        //DoubleSolenoid
        intakePiston = new DoubleSolenoid(0, 1);
        
        //Talon
        frontLeft = new Talon(0);
        backLeft = new Talon(1);
        frontRight = new Talon(2);
        backRight = new Talon(3);
        
        //RobotDrive
        myRobot = new RobotDrive(frontLeft, backLeft, frontRight, backRight);
        myRobot.setExpiration(0.1);
        
        //Victor
        leftIntakeMotor = new Victor(4);
        rightIntakeMotor = new Victor(5);
        elevatorMotor1 = new Victor(6);
        elevatorMotor2 = new Victor(7);
        
        //Digital Inputs (limit switches)
        //topLimitSwitch = new DigitalInput(0);
        //bottomLimitSwitch = new DigitalInput(1);
    }
    
    public void robotInit() {
    	//compressor.setClosedLoopControl(true);
    	//compressor.enabled();
    	compressor.start();
    	
    	//invert motors
    	myRobot.setInvertedMotor(RobotDrive.MotorType.kFrontLeft, true);
    	myRobot.setInvertedMotor(RobotDrive.MotorType.kRearLeft, true);
    	myRobot.setInvertedMotor(RobotDrive.MotorType.kFrontRight, true);
    	myRobot.setInvertedMotor(RobotDrive.MotorType.kRearRight, true);
    	
    	//set drive speed
    	//frontLeft.set(speed);
        //backLeft.set(speed);
        //frontRight.set(speed);
        //backRight.set(speed);
    }

    
     // Drive left & right motors for 2 seconds then stop
    public void autonomous() {
    	
    	time = System.currentTimeMillis();
    	myRobot.setSafetyEnabled(false);
    	
    	while (System.currentTimeMillis() - time < 2500) {
    		myRobot.drive(-0.5, 0.0);
    	}
    	
    	time = System.currentTimeMillis();
        
        	// drive forwards half speed
        //Timer.delay(2.0);		//    for 2 seconds
        myRobot.drive(0.0, 0.0);	// stop robot
        
    }

    //Runs the motors with arcade steering.
    public void operatorControl() {
        myRobot.setSafetyEnabled(true);
        while (isOperatorControl() && isEnabled()) {
            myRobot.arcadeDrive(mainJoystick); // drive with arcade style (use right stick)
            Timer.delay(0.005);		// wait for a motor update time
            
            if (secondJoystick.getRawButton(OPEN_INTAKE_2) ) {
            	intakePiston.set(DoubleSolenoid.Value.kReverse);
            } else if (secondJoystick.getRawButton(CLOSE_INTAKE_2)) {
            	intakePiston.set(DoubleSolenoid.Value.kForward);
            }
            
            if (secondJoystick.getRawButton(INTAKE_IN_2)) {
            	leftIntakeMotor.set(1.0);
            	rightIntakeMotor.set(1.0);
            } else if (secondJoystick.getRawButton(INTAKE_OUT_2)) {
            	leftIntakeMotor.set(-1.0);
            	rightIntakeMotor.set(-1.0);
            } else if (secondJoystick.getRawButton(TURN_LEFT_2)) {
            	leftIntakeMotor.set(-1.0);
            	rightIntakeMotor.set(1.0);
            } else if (secondJoystick.getRawButton(TURN_RIGHT_2)) {
            	leftIntakeMotor.set(1.0);
            	rightIntakeMotor.set(-1.0);
            } else {
            	leftIntakeMotor.set(0);
            	rightIntakeMotor.set(0);
            }
            
            if (mainJoystick.getRawButton(ELEVATOR_UP_1)) {
            	elevatorMotor1.set(-0.9);
            	elevatorMotor2.set(-0.9);
            } else if (mainJoystick.getRawButton(ELEVATOR_DOWN_1)) {
            	elevatorMotor1.set(0.9);
            	elevatorMotor2.set(0.9);
            } else {
            	elevatorMotor1.set(holdValue);
            	elevatorMotor2.set(holdValue);
            }
            
            if (mainJoystick.getRawButton(HOLD_UP_1)) {
            	holdValue = -0.1;
            } else if (mainJoystick.getRawButton(HOLD_DOWN_1)) {
            	holdValue = 0.3;
            }
            /*
            if (mainJoystick.getRawButton(INCREASE_SPEED_LIMIT)) {
            	if (System.currentTimeMillis() - time > 80 && speed < 1) {
            		speed += 0.1;
            	}
            	time = System.currentTimeMillis();
            } else if (mainJoystick.getRawButton(DECREASE_SPEED_LIMIT)) {
            	if (System.currentTimeMillis() - time > 80 && speed > 0.1) {
            		speed -= 0.1;
            	}
            	time = System.currentTimeMillis();
            }
            */
        }
    }

    //Runs during test mode
    public void test() {
    }
}
